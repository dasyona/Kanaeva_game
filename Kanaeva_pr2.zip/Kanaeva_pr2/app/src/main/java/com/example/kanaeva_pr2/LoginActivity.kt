package com.example.kanaeva_pr2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Проверка: если логин уже сохранен, пропускаем экран входа
        val prefs = getSharedPreferences("GamePrefs", MODE_PRIVATE)
        if (prefs.getString("username", null) != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val name = etUsername.text.toString().trim()
            if (name.isNotEmpty()) {
                // Сохраняем логин
                prefs.edit().putString("username", name).apply()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }
}
