package com.example.kanaeva_pr2

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "difficulty_table")
data class DifficultyLevelsDbEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val levelName: String,
    val description: String, // Новое поле
    val difficultyLevel: Int, // Новое поле
    val abilities: Array<String>,
    val imageBytes: ByteArray? = null
) {
    // Обязательно переопределяем для корректной работы Room
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as DifficultyLevelsDbEntity
        if (id != other.id) return false
        if (levelName != other.levelName) return false
        if (description != other.description) return false
        if (difficultyLevel != other.difficultyLevel) return false
        if (!abilities.contentEquals(other.abilities)) return false
        if (imageBytes != null) {
            if (other.imageBytes == null) return false
            if (!imageBytes.contentEquals(other.imageBytes)) return false
        } else if (other.imageBytes != null) return false
        return true
    }

    override fun hashCode(): Int {
        var result = id
        result = 31 * result + levelName.hashCode()
        result = 31 * result + description.hashCode()
        result = 31 * result + difficultyLevel
        result = 31 * result + abilities.contentHashCode()
        result = 31 * result + (imageBytes?.contentHashCode() ?: 0)
        return result
    }
}