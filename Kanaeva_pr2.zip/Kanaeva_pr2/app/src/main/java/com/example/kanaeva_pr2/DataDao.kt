package com.example.kanaeva_pr2

import androidx.room.*

@Dao
interface DataDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertData(data: DifficultyLevelsDbEntity)

    @Query("SELECT * FROM difficulty_table")
    suspend fun getAllData(): List<DifficultyLevelsDbEntity>
}