package com.example.kanaeva_pr2

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataAdapter(
    private val dataList: List<DifficultyLevelsDbEntity>,
    private val onItemLongClick: (DifficultyLevelsDbEntity) -> Unit
) : RecyclerView.Adapter<DataAdapter.DataViewHolder>() {

    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val levelName: TextView = view.findViewById(R.id.tvLevelName)
        val description: TextView = view.findViewById(R.id.tvDescription)
        val difficulty: TextView = view.findViewById(R.id.tvDifficulty)
        val imageView: ImageView = view.findViewById(R.id.sprite)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.data_item, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, position: Int) {
        val data = dataList[position]

        holder.levelName.text = data.levelName
        holder.description.text = data.description
        holder.difficulty.text = "Сложность: ${data.difficultyLevel}"

        data.imageBytes?.let { bytes ->
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            holder.imageView.setImageBitmap(bitmap)
        }

        holder.itemView.setOnLongClickListener {
            onItemLongClick(data)
            true
        }
    }

    override fun getItemCount(): Int = dataList.size
}
