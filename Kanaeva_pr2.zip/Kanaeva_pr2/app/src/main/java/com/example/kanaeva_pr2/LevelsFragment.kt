package com.example.kanaeva_pr2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class LevelsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_levels, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Показываем приветствие с логином
        val prefs = requireActivity().getSharedPreferences("GamePrefs", 0)
        val username = prefs.getString("username", "Player")
        view.findViewById<TextView>(R.id.tvWelcome).text = "Добро пожаловать, $username!"

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Работа с БД
        val db = AppDatabase.getDatabase(requireContext())
        val dao = db.dataDao()

        // Запускаем корутину для получения данных
        viewLifecycleOwner.lifecycleScope.launch {
            // Для демонстрации: если БД пуста, добавим несколько данных
            if (dao.getAllData().isEmpty()) {
                dao.insertData(
                    DifficultyLevelsDbEntity(
                        levelName = "Уровень 1: Розовый рассвет",
                        description = "Легкий старт",
                        difficultyLevel = 1,
                        abilities = arrayOf("Прыжок", "Бег")
                    )
                )
                dao.insertData(
                    DifficultyLevelsDbEntity(
                        levelName = "Уровень 2: Неоновый город",
                        description = "Средняя сложность",
                        difficultyLevel = 5,
                        abilities = arrayOf("Двойной прыжок", "Дэш")
                    )
                )
            }

            // Получаем данные и передаем в адаптер
            val levels = dao.getAllData()
            recyclerView.adapter = DataAdapter(levels) { }
        }
    }
}
